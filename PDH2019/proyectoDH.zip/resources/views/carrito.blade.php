@extends('master')

@section('content')
<div class="container">
    <h1>Mi Carrito</h1>
    <h2>Lista de productos</h2>

    @dd($items)



</div>
@endsection