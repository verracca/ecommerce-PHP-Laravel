@extends('master')

@section('content')
  <br>
    <div class="contacto d-flex">
      <div class=" flex-column">
      <h1 class="grande">CONTACTO //</h1>
      <br>
      <br>
      <div class="">
        <h4 class=""><strong>-Telefono:</strong> 12134567687</h4>
        <h4 class=""><strong>-Email:</strong> reparacionescabildo3733@gmail.com</h4>
      </div>
</div>
      <br>
      <div class="justify-content-between mapacontacto">
<iframe class=""src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3286.199539639445!2d-58.47031778544371!3d-34.54850286208431!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bcb69c0beeacd5%3A0xe99f31b985d5d1ee!2sAv.%20Cabildo%203733%2C%20C1429AAI%20CABA!5e0!3m2!1ses!2sar!4v1575993814072!5m2!1ses!2sar" width="500" height="500" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
</div>
      </div>
  @endsection
