<?php $__env->startSection('content'); ?>

<section class="d-flex productoentero">
    
      <img class="imgProducto" src="/storage/product/<?php echo e($product->featuredimg); ?>" class="" alt="">
    <section class="d-felx producto">
        <h2><?php echo e($product->name); ?></h2>
        <h1 class="precioproducto"> $<?php echo e($product->price); ?></h1>
        <section class="row nuñez">
        <i class="fas fa-truck"></i>
          <p class="ubicacion">Envios a todo el pais</p>
        </section>
        <section class="row nuñez">
          <i class="fas fa-location-arrow"></i>
          <p class="ubicacion">Nuñez, C.A.B.A.</p>
        </section>
        <br>
        <div class="container productosolo">
            <section class="row ">
                <select class="custom-select col-xl-4" id="inlineFormCustomSelectPref">
                    <option value="0">Cantidad</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                </select>
                <button type="button" class=" btn btn-primary col-xl-4 botoncarrito">Agregar al carrito  <i class="fas fa-shopping-cart"></i></button>
            </section>
        </div>
        <br>
        <br>
        <p><?php echo e($product->description); ?></p>
        <br>
        <br>
    </section>
</section>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PDH2019Laravel\PDH2019\resources\views/producto.blade.php ENDPATH**/ ?>