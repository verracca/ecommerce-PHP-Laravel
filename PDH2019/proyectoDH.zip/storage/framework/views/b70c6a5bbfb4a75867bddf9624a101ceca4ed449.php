<?php $__env->startSection('content'); ?>
  <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <article class="">
       <div class="card mb-3 articulos" style="max-width: 1200px;">
  <div class="row no-gutters">
    <div class="col-md-4">
      <img src="/storage/product/<?php echo e($product->featuredimg); ?>" class="card-img" alt="...">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h4 class="card-title"<a href="/producto/<?php echo e($product->id); ?>"><?php echo e($product->name); ?></a></h4>
        <p class="card-text"><?php echo e($product->description); ?></p>
        <h5 class="card-text">Precio: <?php echo e($product->price); ?>$</h5>
        <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
      </div>
    </div>
  </div>
</div>
    </article>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p>No hay productos disponibles</p>
  <?php endif; ?>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PDH2019Laravel\PDH2019\resources\views/categories.blade.php ENDPATH**/ ?>